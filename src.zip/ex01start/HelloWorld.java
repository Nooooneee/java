package ex01start;

public class HelloWorld{
	public static void main(String[] args){
		System.out.println("Hello World...!!");
		System.out.println("안녕하세요.!!");
	}
}